(function ($) {

  // Handle click on toggle search button
  $('#toggle-search').click(function () {
    $('#search-form, #toggle-search').toggleClass('open');
    return false;
  });

  // Handle click on search submit button
  $('#search-form input[type=submit]').click(function () {
    $('#search-form, #toggle-search').toggleClass('open');
    return true;
  });

  // Clicking outside the search form closes it
  $(document).click(function (event) {
    var target = $(event.target);

    if (!target.is('#toggle-search') && !target.closest('#search-form').size()) {
      $('#search-form, #toggle-search').removeClass('open');
    }
  });
  $(".hamburger").click(function () {
    $(this).toggleClass("is-active");
  });

})(jQuery); // JavaScript Document




$('.counting').each(function() {
  var $this = $(this),
      countTo = $this.attr('data-count');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },
  {
    duration: 3000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
});


$(document).ready(function() {
		//
//		$('.autoplay').slick({
//  slidesToShow: 1,
//  slidesToScroll: 1,
//  autoplay: false,
//  autoplaySpeed: 2000,
//});
$('.owl-carousel').owlCarousel({
                loop: true,
                margin: 20,
                responsiveClass: true,
				autoplay: false,
                responsive: {
                  0: {
                    items: 1,
                    nav: false
                  },
                  600: {
                    items: 1,
                    nav: false
                  },
                  1000: {
                    items: 1,
                    nav: false,
                    loop: true,
                    margin: 20
                  }
                }
})
 })


$(document).ready(function () {
//  $('.carousel').on('slide.bs.carousel', function() {
//  $(".carousel-indicators2 li").removeClass("active");
//  indicators = $(".carousel-indicators li.active").data("data-bs-slide-to");
//  a = $(".carousel-indicators2").find("[data-bs-slide-to='" + indicators + "']").addClass("active");
//  console.log(indicators);
//
//})

});
$(document).ready(function () {

	$("#bookacall").click(function() {
    $('html, body').animate({
        scrollTop: $("#pills-tab").offset().top
    }, 1000);
});
	
});


$('.carousel').on('slid.bs.carousel', function(evt) {
    
//      console.log("slide transition started")
//   console.log('current slide = ', $(this).find('.active').index())
//   console.log('next slide = ', $(evt.relatedTarget).index())
  $(".carousel-indicators2 li").removeClass("active");
  $(".carousel-indicators2").find("[data-bs-slide-to='" + $(evt.relatedTarget).index() + "']").addClass("active")
  
//   indicators = $(".carousel-indicators li.active").data("bs-slide-to");
//   a = $(".carousel-indicators2").find("[data-bs-slide-to='" + indicators + "']").addClass("active");
//   console.log(indicators);

})